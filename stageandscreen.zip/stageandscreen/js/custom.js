document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.getElementById("menu-toggle");
  const menu = document.getElementById("superfish-account-accordion");

  if(toggle && menu){
    toggle.addEventListener("click", function () {
      if (menu.style.display === "none" || menu.style.display === "") {
        menu.style.display = "block";
      } else {
        menu.style.display = "none";
      }
    });
  }

  const headerMenuToggle = document.querySelector('header.header-section button#navToggle');
  const header = document.querySelector('header.header-section');
  if(headerMenuToggle){
    headerMenuToggle.addEventListener('click', function(){
      header.classList.toggle('menu-open');
    })
  }
});

// Change bg video on hover effect.
document.addEventListener("DOMContentLoaded", function () {
  const listItems = document.querySelectorAll(".dynamic-bg__description .field--name-field-description ul li");
  const fieldItems = document.querySelectorAll(".field--name-field-select-paragraph .field__item");
  
  function activateItem(index) {
    // Update active class on list items
    listItems.forEach((li, i) => {
      li.classList.toggle("active", i === index);
    });

    // Show corresponding .field__item
    fieldItems.forEach((item, i) => {
      item.style.display = i === index ? "block" : "none";
    });
  }

  // Set default active and visible on first item
  activateItem(0);

  // Add hover event
  listItems.forEach((li, index) => {
    li.addEventListener("mouseenter", () => {
      activateItem(index);
    });
  });
});


//User login, register & password reset form placeholder
document.addEventListener("DOMContentLoaded", function () {
  // Target textfield input
  const textInput = document.querySelector(".user-login-form .js-form-type-textfield input");
  if (textInput) {
    textInput.placeholder = "Username";
  }

  const passwordInput = document.querySelector(".user-login-form .js-form-type-password input");
  if (passwordInput) {
    passwordInput.placeholder = "Password";
  }

  const ResetPass = document.querySelector(".user-pass .js-form-type-textfield input");
  if (ResetPass) {
    ResetPass.placeholder = "Email";
  }

  const submitButton = document.querySelector(".user-pass .form-actions input[type='submit']");  
  if (submitButton) {
    submitButton.value = "Reset Password"; 
  }

  const UserRegister = document.querySelector(".user-register-form .js-form-type-email input");
  if (UserRegister) {
    UserRegister.placeholder = "Email address";
  }

  const UserRegisterEmail = document.querySelector(".user-register-form .js-form-type-textfield input");
  if (UserRegisterEmail) {
    UserRegisterEmail.placeholder = "Username";
  }
});

document.addEventListener("DOMContentLoaded", () => {
  const DURATION = 2000;

  const animateCounter = (numberEl, target, duration) => {
    const startTime = performance.now();

    const update = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const value = Math.floor(progress * target);
      numberEl.textContent = value.toLocaleString();

      if (progress < 1) {
        requestAnimationFrame(update);
      } else {
        numberEl.textContent = target.toLocaleString();
      }
    };

    requestAnimationFrame(update);
  };

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const heading = entry.target;
        const numberEl = heading.querySelector('.number');

        if (numberEl) {
          const rawValue = numberEl.getAttribute('data-target') || numberEl.textContent;
          const target = parseInt(rawValue.replace(/,/g, ''), 10);

          if (!isNaN(target)) {
            numberEl.textContent = '0'; // reset before animation
            animateCounter(numberEl, target, DURATION);
          }
        }

        observer.unobserve(heading);
      }
    });
  }, {
    threshold: 0.8
  });

  // Select only .feature-card__heading that contain a .number
  const headings = document.querySelectorAll('.feature-card__heading');

  headings.forEach(heading => {
    if (heading.querySelector('.number')) {
      observer.observe(heading);
    }
  });
});



document.addEventListener("DOMContentLoaded", function () {
  // Only run this on mobile devices
  if (window.innerWidth <= 768) {
    const tabList = document.querySelectorAll('.quicktabs-tabs li');
    const wrapperDiv = document.createElement('div');
    wrapperDiv.className = 'mobile-only'; // For styling

    const selectBox = document.createElement('select');
    selectBox.id = 'case-studies-select';

    tabList.forEach((li, index) => {
      const link = li.querySelector('a');
      const option = document.createElement('option');
      option.value = index; // use index for tab identification
      option.textContent = link.textContent === 'All' ? 'All Expertise' : link.textContent;
      selectBox.appendChild(option);
    });

    // On change, simulate tab click
    selectBox.addEventListener('change', function () {
      const selectedIndex = parseInt(this.value);
      const selectedTab = document.querySelectorAll('.quicktabs-tabs li')[selectedIndex];
      if (selectedTab) {
        const tabLink = selectedTab.querySelector('a');
        if (tabLink) {
          tabLink.click(); // Trigger the tab's native behavior
        }
      }
    });

    wrapperDiv.appendChild(selectBox);
    const tabContainer = document.querySelector('.item-list');
    tabContainer.parentNode.insertBefore(wrapperDiv, tabContainer);
  }
});


function setupSelectColor(selectId, placeholderValue = 'NA') {
  const select = document.getElementById(selectId);
  if (!select) return;

  function updateColor() {
    select.style.color = (select.value === placeholderValue) ? '#999' : '#000';
  }

  updateColor(); // Initial state
  select.addEventListener('change', updateColor);
}

// Apply to both selects
setupSelectColor('edit-office-locations');
setupSelectColor('edit-industry');


