document.addEventListener("DOMContentLoaded", function () {
  const toggle = document.getElementById("menu-toggle");
  const menu = document.getElementById("superfish-account-accordion");

  toggle.addEventListener("click", function () {
    if (menu.style.display === "none" || menu.style.display === "") {
      menu.style.display = "block";
    } else {
      menu.style.display = "none";
    }
  });
});

// Change bg video on hover effect.
document.addEventListener("DOMContentLoaded", function () {
  const listItems = document.querySelectorAll(".dynamic-bg__description .field--name-field-description ul li");
  const fieldItems = document.querySelectorAll(".field--name-field-select-paragraph .field__item");
  
  function activateItem(index) {
    // Update active class on list items
    listItems.forEach((li, i) => {
      li.classList.toggle("active", i === index);
    });

    // Show corresponding .field__item
    fieldItems.forEach((item, i) => {
      item.style.display = i === index ? "block" : "none";
    });
  }

  // Set default active and visible on first item
  activateItem(0);

  // Add hover event
  listItems.forEach((li, index) => {
    li.addEventListener("mouseenter", () => {
      activateItem(index);
    });
  });
});


//User login, register & password reset form placeholder
document.addEventListener("DOMContentLoaded", function () {
  // Target textfield input
  const textInput = document.querySelector(".user-login-form .js-form-type-textfield input");
  if (textInput) {
    textInput.placeholder = "Username";
  }

  const passwordInput = document.querySelector(".user-login-form .js-form-type-password input");
  if (passwordInput) {
    passwordInput.placeholder = "Password";
  }

  const ResetPass = document.querySelector(".user-pass .js-form-type-textfield input");
  if (ResetPass) {
    ResetPass.placeholder = "Email";
  }

  const submitButton = document.querySelector(".user-pass .form-actions input[type='submit']");  
  if (submitButton) {
    submitButton.value = "Reset Password"; 
  }

  const UserRegister = document.querySelector(".user-register-form .js-form-type-email input");
  if (UserRegister) {
    UserRegister.placeholder = "Email address";
  }

  const UserRegisterEmail = document.querySelector(".user-register-form .js-form-type-textfield input");
  if (UserRegisterEmail) {
    UserRegisterEmail.placeholder = "Username";
  }
});